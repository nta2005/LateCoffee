const functions = require('firebase-functions');

// // Create and Deploy Your First Cloud Functions
// // https://firebase.google.com/docs/functions/write-firebase-functions
//
// exports.helloWorld = functions.https.onRequest((request, response) => {
//   functions.logger.info("Hello logs!", {structuredData: true});
//   response.send("Hello from Firebase!");
// });

const admin = require('firebase-admin');
admin.initializeApp();
const braintree = require('braintree');
const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');

const validateFirebaseIdToken = async (req, res, next) => {
    console.log('Checking');
    if ((!req.headers.authorization || !req.headers.authorization.startsWith('Bearer ')) &&
        !(req.cookies && req.cookies.__session)) {
        res.status(403).send('Unauthorized');
        return;
    }

    let idToken;
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
        idToken = req.headers.authorization.split('Bearer ')[1];

    } else if (req.cookies) {
        idToken = req.cookies.__session;
    } else {
        res.status(403).send('Unauthorized');
        return;
    }

    try {
        const decodedIdToken = await admin.auth().verifyIdToken(idToken);
        req.user = decodedIdToken;
        next();
        return;
    } catch (error) {
        res.status(403).send('Unauthorized');
        return;
    }
}

//Init App

const app = express();
app.use(cors({ origin: true }));
//app.use(cookieParser);
app.use(validateFirebaseIdToken);

var gateway = new braintree.BraintreeGateway({
    environment: braintree.Environment.Sandbox,
    merchantId: '3dh8tdjsxg5q9sp3',
    publicKey: 'dy3frcmvfr4g8yt4',
    privateKey: 'b0d5d303a9283093b7d79ac0f106cc4d'
});

app.get('/token', (req, response) => {
    gateway.clientToken.generate({}, (err, res) => {
        if (res)
            response.send(JSON.stringify({ error: false, token: res.clientToken }));
        else {
            response.send(JSON.stringify({ error: true, errorObj: err, response: res }));
        }
    })
})

app.post('/checkout', (req, res) => {
    var transactionErrors;
    var amount = req.body.amount;
    var nonce = req.body.payment_method_nonce;

    gateway.transaction.sale({
        amount: amount,
        paymentMethodNonce: nonce,
        options: {
            submitForSettlement: true
        }
    }, (error, result) => {
        if (result.success || result.transaction) {
            response.send(JSON.stringify(result));
        }
        else {
            transactionErrors = result.errors.deepErrors();
            response.send(JSON.stringify(formatErrors(transactionErrors)))
        }
    });
});

exports.widgets = functions.https.onRequest(app);